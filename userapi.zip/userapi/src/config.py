SQLALCHEMY_DATABASE_URI = 'postgresql://ajay:ajay@localhost:5800/todo'
SQLALCHEMY_TRACK_MODIFICATIONS = False
